"use client"

import { useState } from "react"
import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookBrowser } from "./book-browser"
import { MyIssues } from "./my-issues"
import { LogOut, BookOpen } from "lucide-react"

export function MemberPortal() {
  const { logout } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("browse")

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <header className="bg-slate-800/50 border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-8 h-8 text-blue-400" />
            <h1 className="text-2xl font-bold text-white">Library Member</h1>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="gap-2 border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-slate-800 border border-slate-700">
            <TabsTrigger value="browse" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Browse Books
            </TabsTrigger>
            <TabsTrigger value="myissues" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              My Issues
            </TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="mt-6">
            <BookBrowser />
          </TabsContent>

          <TabsContent value="myissues" className="mt-6">
            <MyIssues />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
