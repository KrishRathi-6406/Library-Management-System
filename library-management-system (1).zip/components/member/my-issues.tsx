"use client"

import { useState } from "react"
import { getIssuesByMember, getBooks, getCurrentUser, returnBook } from "@/lib/storage"
import type { BookIssue } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { RotateCcw, AlertCircle } from "lucide-react"

export function MyIssues() {
  const user = getCurrentUser()
  const [issues, setIssues] = useState<BookIssue[]>(user?.memberId ? getIssuesByMember(user.memberId) : [])
  const books = getBooks()

  const handleReturnBook = (issueId: string) => {
    returnBook(issueId)
    if (user?.memberId) {
      setIssues(getIssuesByMember(user.memberId))
    }
  }

  const getBookTitle = (bookId: string) => {
    return books.find((b) => b.id === bookId)?.title || "Unknown"
  }

  const isOverdue = (dueDate: string) => {
    return new Date(dueDate) < new Date()
  }

  const activeIssues = issues.filter((i) => i.status === "issued")
  const returnedIssues = issues.filter((i) => i.status === "returned")

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-bold text-white mb-4">Active Issues</h2>
        {activeIssues.length === 0 ? (
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6 text-center text-slate-400">You have no active book issues.</CardContent>
          </Card>
        ) : (
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/50">
                    <TableHead className="text-slate-300">Book</TableHead>
                    <TableHead className="text-slate-300">Issue Date</TableHead>
                    <TableHead className="text-slate-300">Due Date</TableHead>
                    <TableHead className="text-slate-300">Status</TableHead>
                    <TableHead className="text-slate-300">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeIssues.map((issue) => (
                    <TableRow key={issue.id} className="border-slate-700 hover:bg-slate-700/50">
                      <TableCell className="text-slate-300">{getBookTitle(issue.bookId)}</TableCell>
                      <TableCell className="text-slate-300">{new Date(issue.issueDate).toLocaleDateString()}</TableCell>
                      <TableCell className={isOverdue(issue.dueDate) ? "text-red-400" : "text-slate-300"}>
                        {new Date(issue.dueDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        {isOverdue(issue.dueDate) ? (
                          <span className="flex items-center gap-1 px-2 py-1 bg-red-900/30 text-red-400 rounded text-sm w-fit">
                            <AlertCircle className="w-4 h-4" />
                            Overdue
                          </span>
                        ) : (
                          <span className="px-2 py-1 bg-blue-900/30 text-blue-400 rounded text-sm">Active</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          onClick={() => handleReturnBook(issue.id)}
                          className="gap-2 bg-green-600 hover:bg-green-700"
                        >
                          <RotateCcw className="w-4 h-4" />
                          Return
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>

      <div>
        <h2 className="text-xl font-bold text-white mb-4">Return History</h2>
        {returnedIssues.length === 0 ? (
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6 text-center text-slate-400">No returned books yet.</CardContent>
          </Card>
        ) : (
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/50">
                    <TableHead className="text-slate-300">Book</TableHead>
                    <TableHead className="text-slate-300">Issue Date</TableHead>
                    <TableHead className="text-slate-300">Return Date</TableHead>
                    <TableHead className="text-slate-300">Fine</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {returnedIssues.map((issue) => (
                    <TableRow key={issue.id} className="border-slate-700 hover:bg-slate-700/50">
                      <TableCell className="text-slate-300">{getBookTitle(issue.bookId)}</TableCell>
                      <TableCell className="text-slate-300">{new Date(issue.issueDate).toLocaleDateString()}</TableCell>
                      <TableCell className="text-slate-300">
                        {issue.returnDate ? new Date(issue.returnDate).toLocaleDateString() : "-"}
                      </TableCell>
                      <TableCell className={issue.fine > 0 ? "text-red-400" : "text-green-400"}>
                        ₹{issue.fine}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
