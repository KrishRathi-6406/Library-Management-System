"use client"

import { useState } from "react"
import { getBooks, issueBook, getCurrentUser } from "@/lib/storage"
import type { Book } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen } from "lucide-react"

export function BookBrowser() {
  const [books, setBooks] = useState<Book[]>(getBooks())
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const user = getCurrentUser()

  const categories = ["All", ...new Set(books.map((b) => b.category))]
  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "All" || book.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleRequestBook = (bookId: string) => {
    if (!user?.memberId) return

    const result = issueBook(bookId, user.memberId)
    if (result) {
      setBooks(getBooks())
      alert("Book issued successfully! Due date: " + new Date(result.dueDate).toLocaleDateString())
    } else {
      alert("Unable to issue book. No copies available.")
    }
  }

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <Input
          placeholder="Search by title or author..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
        />

        <div className="flex gap-2 flex-wrap">
          {categories.map((category) => (
            <Button
              key={category}
              onClick={() => setSelectedCategory(category)}
              variant={selectedCategory === category ? "default" : "outline"}
              className={
                selectedCategory === category
                  ? "bg-blue-600 hover:bg-blue-700"
                  : "border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
              }
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredBooks.map((book) => (
          <Card key={book.id} className="bg-slate-800 border-slate-700 flex flex-col">
            <CardHeader>
              <CardTitle className="text-white line-clamp-2">{book.title}</CardTitle>
              <CardDescription className="text-slate-400">{book.author}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 space-y-4">
              <div className="space-y-2 text-sm">
                <p className="text-slate-400">
                  <span className="text-slate-300 font-medium">Category:</span> {book.category}
                </p>
                <p className="text-slate-400">
                  <span className="text-slate-300 font-medium">Year:</span> {book.publishedYear}
                </p>
                <p className="text-slate-400">
                  <span className="text-slate-300 font-medium">Available:</span>{" "}
                  <span className={book.availableCopies > 0 ? "text-green-400" : "text-red-400"}>
                    {book.availableCopies} / {book.totalCopies}
                  </span>
                </p>
              </div>

              <p className="text-slate-400 text-sm line-clamp-3">{book.description}</p>

              <Button
                onClick={() => handleRequestBook(book.id)}
                disabled={book.availableCopies === 0}
                className="w-full gap-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
              >
                <BookOpen className="w-4 h-4" />
                {book.availableCopies > 0 ? "Request Book" : "Not Available"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredBooks.length === 0 && (
        <div className="text-center py-12">
          <p className="text-slate-400">No books found matching your search.</p>
        </div>
      )}
    </div>
  )
}
