"use client"

import { useState } from "react"
import { getIssues, getBooks, getMembers, issueBook, returnBook } from "@/lib/storage"
import type { BookIssue } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, RotateCcw } from "lucide-react"

export function IssueManagement() {
  const [issues, setIssues] = useState<BookIssue[]>(getIssues())
  const [isOpen, setIsOpen] = useState(false)
  const [selectedBook, setSelectedBook] = useState("")
  const [selectedMember, setSelectedMember] = useState("")
  const books = getBooks()
  const members = getMembers()

  const handleIssueBook = () => {
    if (!selectedBook || !selectedMember) return

    issueBook(selectedBook, selectedMember)
    setIssues(getIssues())
    setSelectedBook("")
    setSelectedMember("")
    setIsOpen(false)
  }

  const handleReturnBook = (issueId: string) => {
    returnBook(issueId)
    setIssues(getIssues())
  }

  const getBookTitle = (bookId: string) => {
    return books.find((b) => b.id === bookId)?.title || "Unknown"
  }

  const getMemberName = (memberId: string) => {
    return members.find((m) => m.id === memberId)?.name || "Unknown"
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">Book Issues</h2>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4" />
              Issue Book
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-800 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-white">Issue Book to Member</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-slate-300 mb-2 block">Select Book</label>
                <Select value={selectedBook} onValueChange={setSelectedBook}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Choose a book" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    {books
                      .filter((b) => b.availableCopies > 0)
                      .map((book) => (
                        <SelectItem key={book.id} value={book.id} className="text-white">
                          {book.title} ({book.availableCopies} available)
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm text-slate-300 mb-2 block">Select Member</label>
                <Select value={selectedMember} onValueChange={setSelectedMember}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Choose a member" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    {members.map((member) => (
                      <SelectItem key={member.id} value={member.id} className="text-white">
                        {member.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleIssueBook} className="w-full bg-blue-600 hover:bg-blue-700">
                Issue Book
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-700 hover:bg-slate-700/50">
                <TableHead className="text-slate-300">Book</TableHead>
                <TableHead className="text-slate-300">Member</TableHead>
                <TableHead className="text-slate-300">Issue Date</TableHead>
                <TableHead className="text-slate-300">Due Date</TableHead>
                <TableHead className="text-slate-300">Status</TableHead>
                <TableHead className="text-slate-300">Fine</TableHead>
                <TableHead className="text-slate-300">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {issues.map((issue) => (
                <TableRow key={issue.id} className="border-slate-700 hover:bg-slate-700/50">
                  <TableCell className="text-slate-300">{getBookTitle(issue.bookId)}</TableCell>
                  <TableCell className="text-slate-300">{getMemberName(issue.memberId)}</TableCell>
                  <TableCell className="text-slate-300">{new Date(issue.issueDate).toLocaleDateString()}</TableCell>
                  <TableCell className="text-slate-300">{new Date(issue.dueDate).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <span
                      className={`px-2 py-1 rounded text-sm ${
                        issue.status === "returned"
                          ? "bg-green-900/30 text-green-400"
                          : "bg-yellow-900/30 text-yellow-400"
                      }`}
                    >
                      {issue.status}
                    </span>
                  </TableCell>
                  <TableCell className="text-slate-300">₹{issue.fine}</TableCell>
                  <TableCell>
                    {issue.status === "issued" && (
                      <Button
                        size="sm"
                        onClick={() => handleReturnBook(issue.id)}
                        className="gap-2 bg-green-600 hover:bg-green-700"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Return
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
