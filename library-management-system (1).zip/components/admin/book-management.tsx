"use client"

import { useState } from "react"
import { getBooks, addBook, updateBook, deleteBook } from "@/lib/storage"
import type { Book } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Plus, Trash2, Edit2 } from "lucide-react"

export function BookManagement() {
  const [books, setBooks] = useState<Book[]>(getBooks())
  const [isOpen, setIsOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    isbn: "",
    category: "",
    totalCopies: 1,
    publishedYear: new Date().getFullYear(),
    description: "",
  })

  const handleAddBook = () => {
    if (!formData.title || !formData.author) return

    if (editingId) {
      updateBook(editingId, {
        ...formData,
        availableCopies: formData.totalCopies,
      })
      setEditingId(null)
    } else {
      addBook({
        ...formData,
        availableCopies: formData.totalCopies,
      })
    }

    setBooks(getBooks())
    setFormData({
      title: "",
      author: "",
      isbn: "",
      category: "",
      totalCopies: 1,
      publishedYear: new Date().getFullYear(),
      description: "",
    })
    setIsOpen(false)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure?")) {
      deleteBook(id)
      setBooks(getBooks())
    }
  }

  const handleEdit = (book: Book) => {
    setFormData({
      title: book.title,
      author: book.author,
      isbn: book.isbn,
      category: book.category,
      totalCopies: book.totalCopies,
      publishedYear: book.publishedYear,
      description: book.description,
    })
    setEditingId(book.id)
    setIsOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">Book Inventory</h2>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingId(null)} className="gap-2 bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4" />
              Add Book
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-800 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-white">{editingId ? "Edit Book" : "Add New Book"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <Input
                placeholder="Author"
                value={formData.author}
                onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <Input
                placeholder="ISBN"
                value={formData.isbn}
                onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <Input
                placeholder="Category"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <Input
                type="number"
                placeholder="Total Copies"
                value={formData.totalCopies}
                onChange={(e) => setFormData({ ...formData, totalCopies: Number.parseInt(e.target.value) })}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <Input
                type="number"
                placeholder="Published Year"
                value={formData.publishedYear}
                onChange={(e) => setFormData({ ...formData, publishedYear: Number.parseInt(e.target.value) })}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <textarea
                placeholder="Description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full bg-slate-700 border border-slate-600 text-white rounded-md p-2"
              />
              <Button onClick={handleAddBook} className="w-full bg-blue-600 hover:bg-blue-700">
                {editingId ? "Update Book" : "Add Book"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-700 hover:bg-slate-700/50">
                <TableHead className="text-slate-300">Title</TableHead>
                <TableHead className="text-slate-300">Author</TableHead>
                <TableHead className="text-slate-300">Category</TableHead>
                <TableHead className="text-slate-300">Total</TableHead>
                <TableHead className="text-slate-300">Available</TableHead>
                <TableHead className="text-slate-300">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {books.map((book) => (
                <TableRow key={book.id} className="border-slate-700 hover:bg-slate-700/50">
                  <TableCell className="text-slate-300">{book.title}</TableCell>
                  <TableCell className="text-slate-300">{book.author}</TableCell>
                  <TableCell className="text-slate-300">{book.category}</TableCell>
                  <TableCell className="text-slate-300">{book.totalCopies}</TableCell>
                  <TableCell className="text-slate-300">{book.availableCopies}</TableCell>
                  <TableCell className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(book)}
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(book.id)}
                      className="border-red-600 text-red-400 hover:bg-red-900/20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
