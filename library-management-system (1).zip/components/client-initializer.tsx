"use client"

import { useEffect } from "react"
import { initializeStorage } from "@/lib/storage"

export function ClientInitializer() {
  useEffect(() => {
    initializeStorage()
  }, [])

  return null
}
