"use client"

import { useEffect, useState } from "react"
import type { User } from "@/lib/types"
import { getCurrentUser, loginUser, logoutUser } from "@/lib/storage"

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const currentUser = getCurrentUser()
    setUser(currentUser)
    setLoading(false)
  }, [])

  const login = (email: string, password: string) => {
    const user = loginUser(email, password)
    setUser(user)
    return user
  }

  const logout = () => {
    logoutUser()
    setUser(null)
  }

  return { user, loading, login, logout }
}
