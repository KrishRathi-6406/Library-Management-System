"use client"

import { ProtectedRoute } from "@/components/protected-route"
import { MemberPortal } from "@/components/member/member-portal"

export default function MemberPage() {
  return (
    <ProtectedRoute requiredRole="member">
      <MemberPortal />
    </ProtectedRoute>
  )
}
