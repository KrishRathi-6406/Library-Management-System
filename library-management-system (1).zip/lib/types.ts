// Database schema types for the library management system

export interface Book {
  id: string
  title: string
  author: string
  isbn: string
  category: string
  totalCopies: number
  availableCopies: number
  publishedYear: number
  description: string
  createdAt: string
}

export interface Member {
  id: string
  name: string
  email: string
  phone: string
  membershipDate: string
  status: "active" | "inactive"
  createdAt: string
}

export interface BookIssue {
  id: string
  bookId: string
  memberId: string
  issueDate: string
  dueDate: string
  returnDate: string | null
  fine: number
  status: "issued" | "returned" | "overdue"
}

export interface User {
  id: string
  email: string
  password: string
  role: "admin" | "member"
  memberId?: string
  createdAt: string
}
