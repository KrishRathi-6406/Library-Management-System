// LocalStorage management for the library system
import type { Book, Member, BookIssue, User } from "./types"

const STORAGE_KEYS = {
  BOOKS: "library_books",
  MEMBERS: "library_members",
  ISSUES: "library_issues",
  USERS: "library_users",
  CURRENT_USER: "library_current_user",
}

// Initialize with sample data
export function initializeStorage() {
  if (typeof window === "undefined") return

  if (!localStorage.getItem(STORAGE_KEYS.BOOKS)) {
    const sampleBooks: Book[] = [
      {
        id: "1",
        title: "The Great Gatsby",
        author: "F. Scott Fitzgerald",
        isbn: "978-0743273565",
        category: "Fiction",
        totalCopies: 5,
        availableCopies: 3,
        publishedYear: 1925,
        description: "A classic American novel set in the Jazz Age.",
        createdAt: new Date().toISOString(),
      },
      {
        id: "2",
        title: "To Kill a Mockingbird",
        author: "Harper Lee",
        isbn: "978-0061120084",
        category: "Fiction",
        totalCopies: 4,
        availableCopies: 2,
        publishedYear: 1960,
        description: "A gripping tale of racial injustice and childhood innocence.",
        createdAt: new Date().toISOString(),
      },
      {
        id: "3",
        title: "1984",
        author: "George Orwell",
        isbn: "978-0451524935",
        category: "Dystopian",
        totalCopies: 3,
        availableCopies: 1,
        publishedYear: 1949,
        description: "A dystopian novel about totalitarianism.",
        createdAt: new Date().toISOString(),
      },
    ]
    localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(sampleBooks))
  }

  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    const sampleUsers: User[] = [
      {
        id: "1",
        email: "admin@library.com",
        password: "admin123",
        role: "admin",
        createdAt: new Date().toISOString(),
      },
      {
        id: "2",
        email: "member@library.com",
        password: "member123",
        role: "member",
        memberId: "1",
        createdAt: new Date().toISOString(),
      },
    ]
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(sampleUsers))
  }

  if (!localStorage.getItem(STORAGE_KEYS.MEMBERS)) {
    const sampleMembers: Member[] = [
      {
        id: "1",
        name: "John Doe",
        email: "member@library.com",
        phone: "555-0001",
        membershipDate: new Date().toISOString(),
        status: "active",
        createdAt: new Date().toISOString(),
      },
    ]
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(sampleMembers))
  }

  if (!localStorage.getItem(STORAGE_KEYS.ISSUES)) {
    localStorage.setItem(STORAGE_KEYS.ISSUES, JSON.stringify([]))
  }
}

// Books
export function getBooks(): Book[] {
  if (typeof window === "undefined") return []
  const data = localStorage.getItem(STORAGE_KEYS.BOOKS)
  return data ? JSON.parse(data) : []
}

export function addBook(book: Omit<Book, "id" | "createdAt">): Book {
  const books = getBooks()
  const newBook: Book = {
    ...book,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
  }
  books.push(newBook)
  localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(books))
  return newBook
}

export function updateBook(id: string, updates: Partial<Book>): Book | null {
  const books = getBooks()
  const index = books.findIndex((b) => b.id === id)
  if (index === -1) return null
  books[index] = { ...books[index], ...updates }
  localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(books))
  return books[index]
}

export function deleteBook(id: string): boolean {
  const books = getBooks()
  const filtered = books.filter((b) => b.id !== id)
  if (filtered.length === books.length) return false
  localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(filtered))
  return true
}

// Members
export function getMembers(): Member[] {
  if (typeof window === "undefined") return []
  const data = localStorage.getItem(STORAGE_KEYS.MEMBERS)
  return data ? JSON.parse(data) : []
}

export function addMember(member: Omit<Member, "id" | "createdAt">): Member {
  const members = getMembers()
  const newMember: Member = {
    ...member,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
  }
  members.push(newMember)
  localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members))
  return newMember
}

export function getMemberById(id: string): Member | null {
  const members = getMembers()
  return members.find((m) => m.id === id) || null
}

// Book Issues
export function getIssues(): BookIssue[] {
  if (typeof window === "undefined") return []
  const data = localStorage.getItem(STORAGE_KEYS.ISSUES)
  return data ? JSON.parse(data) : []
}

export function issueBook(bookId: string, memberId: string): BookIssue | null {
  const books = getBooks()
  const book = books.find((b) => b.id === bookId)
  if (!book || book.availableCopies <= 0) return null

  const issues = getIssues()
  const newIssue: BookIssue = {
    id: Date.now().toString(),
    bookId,
    memberId,
    issueDate: new Date().toISOString(),
    dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
    returnDate: null,
    fine: 0,
    status: "issued",
  }

  issues.push(newIssue)
  updateBook(bookId, { availableCopies: book.availableCopies - 1 })
  localStorage.setItem(STORAGE_KEYS.ISSUES, JSON.stringify(issues))
  return newIssue
}

export function returnBook(issueId: string): BookIssue | null {
  const issues = getIssues()
  const issue = issues.find((i) => i.id === issueId)
  if (!issue) return null

  const book = getBooks().find((b) => b.id === issue.bookId)
  if (book) {
    updateBook(book.id, { availableCopies: book.availableCopies + 1 })
  }

  issue.returnDate = new Date().toISOString()
  issue.status = "returned"

  const dueDate = new Date(issue.dueDate)
  const returnDate = new Date(issue.returnDate)
  if (returnDate > dueDate) {
    const daysOverdue = Math.floor((returnDate.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24))
    issue.fine = daysOverdue * 10
  }

  localStorage.setItem(STORAGE_KEYS.ISSUES, JSON.stringify(issues))
  return issue
}

export function getIssuesByMember(memberId: string): BookIssue[] {
  const issues = getIssues()
  return issues.filter((i) => i.memberId === memberId)
}

// Users
export function getUsers(): User[] {
  if (typeof window === "undefined") return []
  const data = localStorage.getItem(STORAGE_KEYS.USERS)
  return data ? JSON.parse(data) : []
}

export function getCurrentUser(): User | null {
  if (typeof window === "undefined") return null
  const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER)
  return data ? JSON.parse(data) : null
}

export function setCurrentUser(user: User | null): void {
  if (typeof window === "undefined") return
  if (user) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user))
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER)
  }
}

export function loginUser(email: string, password: string): User | null {
  const users = getUsers()
  const user = users.find((u) => u.email === email && u.password === password)
  if (user) {
    setCurrentUser(user)
    return user
  }
  return null
}

export function logoutUser(): void {
  setCurrentUser(null)
}
